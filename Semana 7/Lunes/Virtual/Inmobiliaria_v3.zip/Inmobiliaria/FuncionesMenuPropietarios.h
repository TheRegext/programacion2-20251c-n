#pragma once

void agregarPropietario();
void bajaPropietario();
void modificarCliente();
void listarPropietarios();
void buscarPorDni();
void buscarTodasLasPropiedadesDelCliente();
void listarInactivos();
