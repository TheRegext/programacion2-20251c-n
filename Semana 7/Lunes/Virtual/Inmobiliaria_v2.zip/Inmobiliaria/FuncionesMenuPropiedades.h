#pragma once

void agregarPropiedad();
void bajaPropiedad();
void modificarPrecio();
void listarPropiedades();
void buscarPorCalle();
void buscarPorRangoPrecios();
void reactivarPropiedad();
